package com.miempresa.usuarios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsuariosAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsuariosAppApplication.class, args);
	}

}



