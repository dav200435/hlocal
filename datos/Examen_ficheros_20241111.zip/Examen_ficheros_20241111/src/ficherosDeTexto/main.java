package ficherosDeTexto;

public class main {
	public static void main(String[] args) {
		// TODO: Crear una instancia de GestionAlumnos para gestionar la lista de alumnos

		// TODO: Agregar 5 alumnos a la lista 

		// TODO: Llamar al método exportarAlumnosAJson de la instancia gestionAlumnos para exportar la lista a un archivo JSON llamado "Alumnos.json"
    }
}
