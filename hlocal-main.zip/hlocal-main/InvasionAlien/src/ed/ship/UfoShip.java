package ed.ship;

public class UfoShip {

}
