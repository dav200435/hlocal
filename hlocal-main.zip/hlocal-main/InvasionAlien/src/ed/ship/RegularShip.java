package ed.ship;

public class RegularShip {

}
