package ed.ship;

public class DestroyerShip {

}
