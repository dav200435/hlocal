package vehiculos;

public class Vehiculo {
	private String color;
	
	public Vehiculo() {
		
	}
	
	public Vehiculo(String color) {
		this.color = color;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}
	
}
