package ejercicios;

import java.util.Scanner;

public class prueba {
public static void main(String[] args){
	Scanner sc = new Scanner(System.in);
	for (int i = 0;i<10;i++) {
		System.out.print(i);
	}
}
}
